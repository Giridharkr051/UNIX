ls -l | txt2docx 
