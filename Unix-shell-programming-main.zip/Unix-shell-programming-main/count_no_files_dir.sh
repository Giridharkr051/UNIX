echo "no of file in this directory is "
ls -l | wc -l
