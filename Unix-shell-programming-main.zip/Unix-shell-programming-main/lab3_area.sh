#!/bin/bash
echo "enter the radius"
read r
echo "area of circle is "
echo "3.14*$r*$r"|bc


