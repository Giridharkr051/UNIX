#!/bin/bash
set -x
set -e
echo "hello"
error
echo "world"

