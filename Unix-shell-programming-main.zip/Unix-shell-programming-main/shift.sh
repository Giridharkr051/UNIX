#!/bin/bash
echo "the arguments are : $*"
echo "$1"
shift 2
echo "$1"

